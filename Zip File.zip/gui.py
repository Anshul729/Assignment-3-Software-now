# gui.py
import tkinter as tk
from tkinter import Text, Scrollbar, messagebox
from models import SentimentModel, SummarizationModel
from helpers import log_execution, timer

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("HIT137 AI GUI")
        self.geometry("900x700")

        # Model objects (initialized later)
        self.model = None
        self.sentiment_model = None
        self.summarization_model = None

        self.create_widgets()

    def create_widgets(self):
        # --- Model Selection Section ---
        tk.Label(self, text="Model Selection:").pack(pady=5)
        self.model_option = tk.StringVar(value="Sentiment Analysis")
        tk.OptionMenu(self, self.model_option, "Sentiment Analysis", "Summarization").pack()
        tk.Button(self, text="Load Model", command=self.load_model).pack(pady=5)

        # --- User Input Section ---
        tk.Label(self, text="User Input:").pack(pady=5)
        frame = tk.Frame(self)
        frame.pack()
        scrollbar = Scrollbar(frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.input_box = Text(frame, height=10, width=100, yscrollcommand=scrollbar.set)
        self.input_box.pack()
        scrollbar.config(command=self.input_box.yview)

        button_frame = tk.Frame(self)
        button_frame.pack(pady=5)
        tk.Button(button_frame, text="Run Model 1", command=self.run_model1).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Run Model 2", command=self.run_model2).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Clear", command=self.clear_input_output).pack(side=tk.LEFT, padx=5)

        # --- Model Output Section ---
        tk.Label(self, text="Model Output:").pack(pady=5)
        self.output_box = Text(self, height=10, width=100)
        self.output_box.pack(pady=5)
        self.output_box.config(state=tk.DISABLED)

        # --- Model Info & OOP Explanation ---
        tk.Label(self, text="Model Information & OOP Explanation:").pack(pady=5)
        self.info_box = Text(self, height=10, width=100)
        self.info_box.pack(pady=5)
        self.info_box.insert(tk.END,
"""Model Info:
1. Sentiment Analysis: Uses distilbert-base-uncased model to classify sentiment.
2. Summarization: Uses t5-small model for summarizing text.

OOP Concepts Used:
- Encapsulation: Model logic is encapsulated in classes.
- Polymorphism & Method Overriding: 'AIModel' base class, 'run_model' overridden.
- Decorators: Logging & timing applied to GUI methods.
- Multiple Inheritance: Tkinter GUI inherits from tk.Tk.""")
        self.info_box.config(state=tk.DISABLED)

    # --- Model Load Function ---
    @log_execution
    @timer
    def load_model(self):
        choice = self.model_option.get()
        if choice == "Sentiment Analysis":
            self.model = SentimentModel()
            self.sentiment_model = self.model
        elif choice == "Summarization":
            self.model = SummarizationModel()
            self.summarization_model = self.model
        messagebox.showinfo("Info", f"{choice} loaded successfully!")

    # --- Run Model Functions ---
    @log_execution
    @timer
    def run_model1(self):
        if not self.sentiment_model:
            messagebox.showwarning("Warning", "Load Sentiment Model first!")
            return
        input_data = self.input_box.get("1.0", tk.END).strip()
        if not input_data:
            messagebox.showwarning("Warning", "Please enter input text.")
            return
        result = self.sentiment_model.run_model(input_data)
        self.display_output(str(result))

    @log_execution
    @timer
    def run_model2(self):
        if not self.summarization_model:
            messagebox.showwarning("Warning", "Load Summarization Model first!")
            return
        input_data = self.input_box.get("1.0", tk.END).strip()
        if not input_data:
            messagebox.showwarning("Warning", "Please enter input text.")
            return
        result = self.summarization_model.run_model(input_data)
        if isinstance(result, list):
            result = result[0]['summary_text']
        self.display_output(str(result))

    # --- Output & Clear Functions ---
    def display_output(self, text):
        self.output_box.config(state=tk.NORMAL)
        self.output_box.delete("1.0", tk.END)
        self.output_box.insert(tk.END, text)
        self.output_box.config(state=tk.DISABLED)

    def clear_input_output(self):
        self.input_box.delete("1.0", tk.END)
        self.output_box.config(state=tk.NORMAL)
        self.output_box.delete("1.0", tk.END)
        self.output_box.config(state=tk.DISABLED)
