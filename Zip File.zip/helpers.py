# helpers.py
import time

# Logging decorator
def log_execution(func):
    def wrapper(*args, **kwargs):
        print(f"Running {func.__name__}...")
        result = func(*args, **kwargs)
        print(f"{func.__name__} finished")
        return result
    return wrapper

# Timer decorator
def timer(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end-start:.2f} seconds")
        return result
    return wrapper
