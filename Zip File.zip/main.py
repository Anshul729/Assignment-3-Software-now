# main.py
from gui import App
from models import SentimentModel, SummarizationModel

if __name__ == "__main__":
    text_model = SentimentModel()
    summarization_model = SummarizationModel()
    app = App()
    # app = App(text_model=text_model, summarization_model=summarization_model)
    app.mainloop()
