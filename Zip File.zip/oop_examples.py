"""
OOP Concepts used in this project:

1. Encapsulation: Model objects are private inside classes.
2. Polymorphism: AIModel base class with run_model() overridden by child classes.
3. Method Overriding: run_model() method is overridden in child classes.
4. Multiple Inheritance: App class inherits from tk.Tk and custom handlers.
5. Decorators: log_execution and timer decorators applied to methods.
"""

"""
oop_example.py

This file demonstrates how OOP concepts are used in our Tkinter + Hugging Face project.
"""

from abc import ABC, abstractmethod

# --- Base Abstract Class (Encapsulation + Abstraction) ---
class AIModel(ABC):
    def __init__(self, model_name):
        self._model_name = model_name   # Encapsulation: attribute made private with _
    
    @abstractmethod
    def run_model(self, input_data):
        pass  # Abstract Method forces child classes to implement (Abstraction)


# --- Polymorphism + Method Overriding ---
class SentimentAnalysisModel(AIModel):
    def __init__(self):
        super().__init__("Sentiment Analysis")

    def run_model(self, input_data):
        # Overriding the abstract method
        return f"Sentiment result for: {input_data}"


class SummarizationModel(AIModel):
    def __init__(self):
        super().__init__("Summarization")

    def run_model(self, input_data):
        # Overriding the abstract method differently (Polymorphism)
        return f"Summary result for: {input_data}"


# --- Multiple Inheritance Example ---
class Logger:
    def log(self, message):
        print(f"[LOG] {message}")


class AdvancedSentimentModel(SentimentAnalysisModel, Logger):
    def run_model(self, input_data):
        self.log("Running Advanced Sentiment Model")   # Using Logger class too
        return super().run_model(input_data)


# --- Decorators Example ---
def log_execution(func):
    def wrapper(*args, **kwargs):
        print(f"Executing {func.__name__}")
        return func(*args, **kwargs)
    return wrapper


class DecoratorDemo:
    @log_execution
    def decorated_method(self):
        print("This method has a decorator applied!")


# --- Testing our OOP concepts ---
if __name__ == "__main__":
    sentiment = SentimentAnalysisModel()
    summary = SummarizationModel()
    adv_sentiment = AdvancedSentimentModel()

    print(sentiment.run_model("I love this!"))
    print(summary.run_model("This is a long text that needs summarization."))
    print(adv_sentiment.run_model("I hate this!"))

    demo = DecoratorDemo()
    demo.decorated_method()

