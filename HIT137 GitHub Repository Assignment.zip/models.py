# models.py
from transformers import pipeline

class AIModel:
    def run_model(self, input_data):
        raise NotImplementedError("This method should be overridden")

class SentimentModel(AIModel):
    def __init__(self):
        # Force PyTorch
        self.model = pipeline("sentiment-analysis", framework="pt")

    def run_model(self, text):
        return self.model(text)

class SummarizationModel(AIModel):
    def __init__(self):
        self.model = pipeline("summarization", framework="pt")

    def run_model(self, text):
        return self.model(text)
